<?php
    print("This is a string...<br/>");
    print(2 + 7 * 3);
    print("<br/>");
    print(49/9);
    print("<br/>");
    print(7%3);
    print("<br/>");
    
    print("2 + 5 / 16 = " . (2+5/16));
    print("<br/>");
    
    print(pi());

    $age = 43;
    print("<br/>I am " . $age . " years old.");
?>