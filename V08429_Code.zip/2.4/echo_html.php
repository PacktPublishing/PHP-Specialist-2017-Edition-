<?php

print("<DOCTYPE html>");
print("<html>");
print("<head><title>Rendered by PHP</title></head>");
print("<body>");
print("<h1>Rendered by PHP</h1>");
print("<p>A complete HTML page can be rendered by PHP and the browser will never know the difference.</p>");
print("</body>");
print("</html>");

?>