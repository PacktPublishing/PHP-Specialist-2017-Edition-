<?php
    //User Defined Constants
    define("SCREENWIDTH", 1920);
    define("SCREENHEIGHT", 1080);
    define("MODE", "2D");

    print("Width: " . SCREENWIDTH);
    print("<br/>Height: " . SCREENHEIGHT);

    //Magic Conctants
    print("<br/>File Name: ". __FILE__);
?>