<?php
    session_start();
    $_SESSION["userID"] = "10105";
    $_SESSION["userNickName"] = "Animal";
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Start Session</title>
    </head>
    <body>
        <p>Session Started</p>
    </body>

</html>