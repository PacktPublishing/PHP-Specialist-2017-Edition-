<?php
    //Strings
    $name = "Mark Lassoff";
    $course = "PHP Specialist";

    //Integers
    $age = 43; 
    $speed = 67;

    //Floating Point
    $gpa = 3.44;
    $grade = 0.78;

    //Boolean
    $phpIsFun = true;
    $isPlaying = false;

    //Null
    $character = "Captain Kangaroo";
    $character = null;

    print($age - 20);
    print("<br/>");
    print($gpa);
    print("<br/>");
    print($phpIsFun);
    print("<br/>");
    print($isPlaying);
    print("<br/>");
    print($character);
?>