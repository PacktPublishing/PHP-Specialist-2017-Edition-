<?php
    print("<h1>Hello World</h1>");
    print("<p>This is my first PHP script</p>");
    print("<p>I am " . 43 . " years old.</p>");
?>