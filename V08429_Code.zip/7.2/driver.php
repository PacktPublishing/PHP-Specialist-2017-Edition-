<?php
    include("include_me.php");
    //include("not_there.php");

    greetMe();
    print("<br/>");
    sayBye();
    

?>