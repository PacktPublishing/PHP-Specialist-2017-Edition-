<?php
function greetMe()
{
    print ("Greetings, from an included file");
}

function sayBye()
{
    print("Adios!");
}

?>