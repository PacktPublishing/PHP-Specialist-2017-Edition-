<?php
    $testGrade = 85;

    if($testGrade >= 90)
    {
        print("A");
    } else if($testGrade >= 80)
    {
        print("B");
    } else if($testGrade >= 70)
    {
        print("C");
    } else if($testGrade >= 60)
    {
        print("D");
    } else
    {
        print("F");
    }
?>