<?php
    $value = 10;

    $x = $value;
    print($x);
    print("<br/>");

    $x += 10;
    print($x);
    print("<br/>");

    $x -= 10;
    print($x);
    print("<br/>");

    $x *= 5;
    print($x);
    print("<br/>");

    $x /= 2;
    print($x);
    print("<br/>");
?>