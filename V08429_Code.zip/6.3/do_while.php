<?php
    
    $x=0;
    do
    {
        print("$x<br/>");
        $x++;
    } while($x < 21);

    print("<br/>******************************<br/>");

    $y=100;
    do
    {
        print($y. "<br/>");
        $y--;
    } while($y>101);

?>