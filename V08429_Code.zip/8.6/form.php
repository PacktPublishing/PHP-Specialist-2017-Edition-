<?php
    $name = $_REQUEST['name'];
    $email = $_REQUEST['email'];

//    $name = $_GET['name'];
//    $email = $_GET['email'];
//
//    $name = $_POST['name'];
//    $email = $_POST['email'];



    print("You entered $name, $email<br/>");
?>