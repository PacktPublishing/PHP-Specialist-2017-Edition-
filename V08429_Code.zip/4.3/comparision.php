<?php
    print("8==8: " . (8==8)); 
    print("<br/>8==6: " . (8==6)); 
   
    $age = 12;
    $stringAge = "12";
    print("<br/>String vs. Int ==: " . ($age == $stringAge));
    print("<br/>String vs. Int ===: " . ($age === $stringAge));
    print("<br/>String vs. Int ==: " . ($age == 
    $stringAge));                                    
    print("<br/>8 != 6: " . (8 != 6));
    print("<br/>4 > 0.6: " . (4 > 0.6));
    print("<br/>2 < 10: " . (2 > 10));
    
?>