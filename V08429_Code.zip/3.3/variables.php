<?php
    $name = "Mark Lassoff";
    $gpa = 3.44;
    $houseNumber = 144;

    print("My name is $name");
    print("<br/>My GPA was: " . $gpa);
    print("<br/>My house number is ");
    print($houseNumber);

?>