<?php
    require("require_me.php");
    //require("not_there.php");

    greetMe();
    print("<br/>");
    sayBye();
    

?>