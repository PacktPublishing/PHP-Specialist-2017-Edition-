<?php

    function printGreetings()
    {
        print("Hello<br/>");
        print("Hi<br/>");
        print("How ya doing?<br/>");
    }

    function sayGoodBye()
    {
        print("<br/>Later dude!");
    }
    printGreetings();

    print("************************<br/>");

    printGreetings();
    sayGoodBye();

?>