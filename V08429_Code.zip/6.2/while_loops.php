<?php

    $x=0;
    while($x<100){
        print($x . "&nbsp;");
        $x++;
    }
    
    print("<br/>");
    print("<br/>");

    $y=0;
    while($y < 10){
        $z = 0;
        while($z < 10)
        {
            print("* ");
            $z++;
        }
        print("<br/>");
        $y++;
    }

?>