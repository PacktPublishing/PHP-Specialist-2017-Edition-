<?php
    print("<h1>This page is produced by PHP and rednered on the server</h1>");
    print("<p>So Hello from PHP!</p>");
?>