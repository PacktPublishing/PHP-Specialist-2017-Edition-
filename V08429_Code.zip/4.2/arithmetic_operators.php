<?php
    $operand1 = 45;
    $operand2 = 12.5;

    print($operand1 . " + " . $operand2 ." = " . ($operand1 + $operand2));
    print("<br/>");
    print($operand1 . " - " . $operand2 ." = " . ($operand1 - $operand2));
     print("<br/>");
    print($operand1 . " * " . $operand2 ." = " . ($operand1 * $operand2));
     print("<br/>");
    print($operand1 . " / " . $operand2 ." = " . ($operand1 / $operand2));
    print("<br/>");
    print(9%3);
    print("<br/>");
    print(10%4);
    print("<br/>");
    print(3**3);
    
?>